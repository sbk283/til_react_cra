import React, { useState } from "react";

function RegisterPage() {
  // js 자리
  // 백엔드로 보낼 데이터를 위한 리액트 변수
  const [formData, setFormData] = useState({
    user_name: "",
    user_email: "",
    user_pw: "",
    user_pw_confirm: "",
    user_nickname: "",
    user_birth: "",
    user_gender: "",
    user_interest: [],
    user_intro: "",
    user_image: null,
    user_thumbnail: "",
  });
  // 필수 항목 체크 오류 메시지 리액트 변수
  const [errMessage, setErrMessage] = useState("");

  // jsx 자리
  return (
    <div>
      <h1>회원 가입</h1>
      <div>회원가입 Form</div>
    </div>
  );
}

export default RegisterPage;
